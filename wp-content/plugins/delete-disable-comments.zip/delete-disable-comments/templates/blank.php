<?php
/**
 * Empty template file to override comments
 *
 * @package Delete & Disable Comments
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// This file intentionally left blank to prevent comment display 

// Silence is golden. 